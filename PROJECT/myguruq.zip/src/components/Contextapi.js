import React from 'react'

function Contextapi() {
    return (
        <>
            <h1>Context API</h1>
        </>
    )
}

export default Contextapi